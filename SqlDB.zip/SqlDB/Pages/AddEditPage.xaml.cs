﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SqlDB.Classes;

namespace SqlDB.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page

        //новое поле, которое будет хранить в себе экземпляры добавляемого пользователя
    {    
        private Person _currentPerson = new Person();
        public AddEditPage()
        {//создаём контекст
            DataContext = _currentPerson;
            InitializeComponent();
            ComboAges.ItemsSource = TestEntities.GetContext().Person.ToList();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentPerson.LastName))
                error.AppendLine("Укажите фамилию");
            if (string.IsNullOrWhiteSpace(_currentPerson.FirstName))
                error.AppendLine("Укажите имя");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            TestEntities.GetContext().Person.Add(_currentPerson);
            try
            {
                TestEntities.GetContext().SaveChanges();
                MessageBox.Show("Новый пользователь добавлен");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
